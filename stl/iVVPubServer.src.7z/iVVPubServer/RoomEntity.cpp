#include "RoomEntity.h"

RoomEntity::RoomEntity(void)
{
}

RoomEntity::~RoomEntity(void)
{
}
