//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RuiTongIVRGUI.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RuiTongIVRGUI_DIALOG        102
#define IDS_CH_FREE                     102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDS_CH_RECEIVEID                104
#define IDS_CH_WAITSECONDRING           105
#define IDS_CH_WELCOME                  106
#define IDS_CH_ACCOUNT                  107
#define IDS_CH_PINNUMBER                108
#define IDS_CH_SELECT                   109
#define IDS_CH_LEAVEMSG                 110
#define IDS_CH_PLAYRECORD               111
#define IDS_CH_PLAYRESULT               112
#define IDS_CH_OFFHOOK                  113
#define IDR_MAINFRAME                   128
#define IDB_BMP_MSG_STATUS              136
#define IDC_BUTTON_SYS_STOP             1000
#define IDC_BUTTON_SYS_QUIT             1001
#define IDC_EDIT_LINE_NO                1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON_RESTART_MONITOR      1003
#define IDC_LIST_SYS_RUN_INFO           1004
#define IDC_LIST_SYS_ERR_INFO           1005
#define IDC_EDIT_SYS_START_TIME         1007
#define IDC_EDIT_SYS_STATE              1009
#define IDC_EDIT_CLIENT_NUM             1010
#define IDC_EDIT_SYS_CUR_TIME           1011
#define IDC_BUTTON_SYS_RUN              1012
#define IDC_BUTTON_SYS_PAUSE            1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
