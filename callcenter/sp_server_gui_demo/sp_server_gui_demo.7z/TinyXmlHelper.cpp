#include "stdafx.h"
#include "TinyXmlHelper.hpp"

#ifndef _CRT_SECURE_NO_DEPRECATE
	#define _CRT_SECURE_NO_DEPRECATE
#endif

#ifndef TIXML_USE_STL
#define TIXML_USE_STL 1
#endif

//
#ifdef WIN32
	#pragma warning(disable:4996)
	#pragma warning(disable:4267)
#endif

//#pragma   push_macro("min")   
//#pragma   push_macro("max")   
//#undef   min   
//#undef   max   
//#include <random>
//#include <regex>
//#pragma   pop_macro("min")   
//#pragma   pop_macro("max")

#include "xpath_static.h"

#ifdef WIN32
#	ifdef _DEBUG
#		pragma comment(lib,"tinyxpathd.lib")
#	else
#		pragma comment(lib,"tinyxpath.lib")
#	endif
#endif

using namespace helper;

xml::xml(): xmlDoc_(new TiXmlDocument), xmlRoot_(0) 
{
}

xml::~xml()
{
	delete xmlDoc_;
}

bool xml::LoadFile(const string& filename)
{
	xmlDoc_->Clear();

	bool ret = xmlDoc_->LoadFile(filename.c_str());
	if(!ret)
	{
		return false;
	}
	xmlRoot_ = xmlDoc_->RootElement();
	if(xmlRoot_ == NULL)
		return false;

	filename_ = filename;

	return true;
}

bool xml::SaveFile()
{
	return xmlDoc_->SaveFile(filename_);
}

bool xml::SaveFile(const char* filename)
{
	return xmlDoc_->SaveFile(filename);
}

bool xml::SaveFile(const string& filename)
{
	return xmlDoc_->SaveFile(filename);
}

bool xml::LoadBuffer(const string& str)
{
	xmlDoc_->Clear();
	xmlDoc_->Parse(str.c_str());
	xmlRoot_ = xmlDoc_->RootElement();
	if(xmlRoot_ == NULL)
		return false;
	return true;
}



Pair xml::GetPair(const string& xpath)
{
	//using namespace std;
	//static tr1::regex  regexAttr("(.+/@\\w+$)");
	//static tr1::regex  regexNode("(^.+/\\w+$)");
	//// xpathָ��һ�����Խ��
	//if(tr1::regex_match(xpath, regexAttr))
	//{
	//	return GetSingleAttr(xpath);
	//}
	//// xpathָ��һ����ͨ���
	//else if(tr1::regex_match(xpath, regexNode))
	//{
	//	return GetSingleNode(xpath);
	//}
	//// ����
	//else
	//	return ValuePair();

	if(xpath.rfind("/@") != npos)
	{
		return GetSingleAttr(xpath);
	}
	// xpathָ��һ����ͨ���
	else if (xpath.rfind("/") != npos)
	{
		return GetSingleNode(xpath);
	}
	// ����
	else
		return Pair();
}

string xml::GetValue(const string& xpath)
{
	if(xpath.rfind("/@") != npos)
	{
		return GetAttrValue(xpath);
	}
	// xpathָ��һ����ͨ���
	else if (xpath.rfind("/") != npos)
	{
		return GetNodeValue(xpath);
	}
	// ����
	else
		return "";
}

string xml::GetValue(const char* xpath)
{
	return GetValue(string(xpath));
}

Pair xml::GetSingleNode(const string& xpath)
{
	Pair p;
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if(node == NULL)
		return p;
	p.first = node->Value();
	TiXmlHandle h(node);
	TiXmlText* t = h.FirstChild().Text();
	if(t == NULL)
		return Pair();
	p.second = t->Value();
	return p;
}

string xml::GetNodeValue(const string& xpath)
{
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if(node == NULL)
		return "";
	TiXmlHandle h(node);
	TiXmlText* t = h.FirstChild().Text();
	if(t == NULL)
		return "";
	return t->Value();
}

string xml::GetNodeValue(const char* xpath)
{
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath);
	if(node == NULL)
		return "";
	TiXmlHandle h(node);
	TiXmlText* t = h.FirstChild().Text();
	if(t == NULL)
		return "";
	return t->Value();
}

bool xml::SetNode(const string& xpath, const string& value)
{
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if(node == NULL)
		return false;
	node->SetValue(value);
	TiXmlHandle h(node);
	TiXmlText* t = h.FirstChild().Text();
	if(t == NULL)
		return false;
	t->SetValue(value);
	return true;
}

bool xml::SetNode(const char* xpath, const char* value)
{
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath);
	if(node == NULL)
		return false;
	TiXmlHandle h(node);
	TiXmlText* t = h.FirstChild().Text();
	if(t == NULL)
		return false;
	t->SetValue(value);
	return true;
}

Pair xml::GetSingleAttr(const string& xpath)
{
	Pair p;
	TiXmlAttribute* attr = TinyXPath::XAp_xpath_attribute(xmlRoot_, xpath.c_str());
	if(attr == NULL)
		return p;
	p.first = attr->Name();
	p.second = attr->Value();
	return p;
}

string xml::GetAttrValue(const string& xpath)
{
	TiXmlAttribute* attr = TinyXPath::XAp_xpath_attribute(xmlRoot_, xpath.c_str());
	if(attr == NULL)
		return "";
	return attr->Value();
}

string xml::GetAttrValue(const char* xpath)
{
	TiXmlAttribute* attr = TinyXPath::XAp_xpath_attribute(xmlRoot_, xpath);
	if(attr == NULL)
		return "";
	return attr->Value();
}

bool xml::SetAttr(const string& xpath, const string& value)
{
	TiXmlAttribute* attr = TinyXPath::XAp_xpath_attribute(xmlRoot_,  xpath.c_str());
	if(attr == NULL)
		return false;	
	attr->SetValue(value);
	return true;
}

bool xml::SetAttr(const char* xpath, const char* value)
{
	TiXmlAttribute* attr = TinyXPath::XAp_xpath_attribute(xmlRoot_,  xpath);
	if(attr == NULL)
		return false;	
	attr->SetValue(value);
	return true;
}

PairSet xml::GetTagAndTextOfChilds(const string& xpath)
{	
	PairSet v;
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if(node == NULL)
		return v;
	if(node->NoChildren())
		return v;
	TiXmlNode* subNode = NULL;
	while(1)
	{
		subNode = node->IterateChildren(subNode);
		if(subNode == NULL)
			break;
		//if(subNode->Type() != TiXmlNode::NodeType::ELEMENT)
		if(subNode->Type() != TiXmlNode::ELEMENT)
			continue;
		Pair p;
		p.first = subNode->Value();
		TiXmlHandle h(subNode);
		TiXmlText* t = h.FirstChild().Text();
		if(t == NULL)
			return PairSet();
		p.second = t->Value();
		v.push_back(p);
	}
	return v;
}

PairSet xml::GetKeyAndTextOfChilds(const string& xpath, const string& attrName)
{
	PairSet v;
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if(node == NULL)
		return v;
	if(node->NoChildren())
		return v;
	TiXmlNode* subNode = NULL;
	while(1)
	{
		subNode = node->IterateChildren(subNode);
		if(subNode == NULL)
			break;
		//if(subNode->Type() != TiXmlNode::NodeType::ELEMENT)
		if(subNode->Type() != TiXmlNode::ELEMENT)
			continue;

		TiXmlAttribute* attr = NULL;
		string attrXPath = string("@") + attrName;
		attr = TinyXPath::XAp_xpath_attribute(subNode, attrXPath.c_str());
		if(attr == NULL)
			continue;
		
		Pair p;
		p.first = attr->Value();
		TiXmlHandle h(subNode);
		TiXmlText* t = h.FirstChild().Text();
		if(t == NULL)
			return PairSet();
		p.second = t->Value();
		v.push_back(p);
	}
	return v;
}

PairSetSet xml::GetAttrsOfChilds(const string& xpath)
{
	PairSetSet m;
	TiXmlNode* node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if(node == NULL)
		return m;
	if(node->NoChildren())
		return m;
	TiXmlNode* subNode = NULL;
	while(1)
	{
		subNode = node->IterateChildren(subNode);
		if(subNode == NULL)
			break;
		//if(subNode->Type() != TiXmlNode::NodeType::ELEMENT)
		if(subNode->Type() != TiXmlNode::ELEMENT)
			continue;

		PairSet v;
		// �õ��������������
		Pair p;
		p.first = subNode->Value();
		TiXmlHandle h(subNode);
		TiXmlText* t = h.FirstChild().Text();
		if(t == NULL)
			p.second = "";
		else
			p.second = t->Value();
		v.push_back(p);
		TiXmlAttribute* attr = NULL;
		// �õ��������
		attr = TinyXPath::XAp_xpath_attribute(subNode, "@*");
		if(attr != NULL)
		{
			v.push_back(Pair(attr->Name(), attr->Value()));
			while(1)
			{
				attr = attr->Next();
				if(attr != NULL)
				{
					v.push_back(Pair(attr->Name(), attr->Value()));
				}
				else
					break;
			}
		}
		m.push_back(v);
	}
	return m;
}


bool xml::InsertNode(const string& xpath, const string& text)
{
	TiXmlElement addThis("");
	//addThis.Parse(text.c_str(), NULL, TiXmlEncoding::TIXML_ENCODING_UTF8);
	addThis.Parse(text.c_str(), NULL, TiXmlEncoding::TIXML_ENCODING_UNKNOWN);
	TiXmlNode * afterThis = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if (afterThis)
	{
		//TiXmlNode* c = afterThis->LastChild();
		//TiXmlNode* n = afterThis->InsertAfterChild(c, addThis);
		//ע�͵����䵱<tag></tag>֮��û������ʱ��ʧ��

		TiXmlNode* n = afterThis->InsertEndChild(addThis);
		if (n)
		{
			return true;
		}
	}
	return false;	
}

bool xml::RemoveNode(const string& xpath)
{
	TiXmlNode * removeThis = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if (removeThis)
	{
		return removeThis->Parent()->RemoveChild(removeThis);
	}	
	return false;
}

bool xml::RemoveNodes(const string& xpath)
{
	TiXmlNode * removeThis = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	while(removeThis)
	{
		if(!removeThis->Parent()->RemoveChild(removeThis))
			return false;
		removeThis = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	}	
	
	return true;
}

bool xml::ClearNode(const string& xpath)
{
	TiXmlNode * node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if(node)
	{
		node->Clear();
		return true;
	}
	return false;	
}

bool xml::IsEmpty(const string& xpath)
{
	TiXmlNode * node = TinyXPath::XNp_xpath_node(xmlRoot_, xpath.c_str());
	if (!node->FirstChild())
	{
		return true;
	}
	return false;
}