// RuiTongIVRGUIDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RuiTongIVRGUI.h"
#include "RuiTongIVRGUIDlg.h"
#include "MainProc.h"
#include "Message.h"
#include <vector>

using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRuiTongIVRGUIDlg dialog

CRuiTongIVRGUIDlg::CRuiTongIVRGUIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRuiTongIVRGUIDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRuiTongIVRGUIDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRuiTongIVRGUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRuiTongIVRGUIDlg)
	//DDX_Control(pDX, IDC_EDIT_CLIENT_NUM, m_txtLinking);
	DDX_Control(pDX, IDC_EDIT_SYS_STATE, m_txtState);
	DDX_Control(pDX, IDC_LIST_SYS_RUN_INFO, m_listSysRunInfo);
	DDX_Control(pDX, IDC_LIST_SYS_ERR_INFO, m_listSysErrInfo);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRuiTongIVRGUIDlg, CDialog)
	//{{AFX_MSG_MAP(CRuiTongIVRGUIDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SYS_RUN, OnButtonSysRun)
	ON_BN_CLICKED(IDC_BUTTON_SYS_PAUSE, OnButtonSysPause)
	ON_BN_CLICKED(IDC_BUTTON_SYS_STOP, OnButtonSysStop)
	ON_BN_CLICKED(IDC_BUTTON_SYS_QUIT, OnButtonSysQuit)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_RESTART_MONITOR, &CRuiTongIVRGUIDlg::OnBnClickedButtonRestartMonitor)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRuiTongIVRGUIDlg message handlers

BOOL CRuiTongIVRGUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
		pSysMenu->EnableMenuItem (6,MF_BYPOSITION|MF_GRAYED);
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	bool bSysInitOk = true;

	if(GlobalOpenUniqueProcess() != 0)
	{//������ڻ��߲��������⣬�����˳�������
		::PostQuitMessage(0);
		bSysInitOk = false;
	}

	if (bSysInitOk)
	{		
		glo_pMainDlg = this;

		if(!InitSysEnv())
		{//��ʼ��ϵͳ
			::PostQuitMessage(0);
		}

		////���ͼ����Ϣ
		//CMessage::SendStartMonitMsg();

		//���ô�������
		SetProp(m_hWnd,g_szTitle,(HANDLE)1);

		m_listSysRunInfo.InitChannel(g_iChannelNum);
		//m_listSysRunInfo.InitChannel(8);

		SetTimer(1,1000,NULL);


		CTime tmNow = CTime::GetCurrentTime();
		CString szNow;
		szNow.Format("%02d%02d %02d:%02d:%02d",
			tmNow.GetMonth(),tmNow.GetDay(),
			tmNow.GetHour(),tmNow.GetMinute(),tmNow.GetSecond());
		DWORD dwID = IDC_EDIT_SYS_START_TIME;
		CEdit* pEdit = (CEdit*)GetDlgItem(dwID);
		pEdit->SetWindowText(szNow.GetString());

		GLog("ϵͳ������");
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRuiTongIVRGUIDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRuiTongIVRGUIDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.

HCURSOR CRuiTongIVRGUIDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//cul
LRESULT CRuiTongIVRGUIDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_APP_WRITE_DATA://��Ӧ�Զ������Ϣ
		{
			//��ȡӳ���ڴ�����
			vector<string > strVector;
			string id;
			string phone;
			string stat;
			if(m_memMsg.Read(strVector))
			{
				for(vector<string >::size_type i = 0; i<strVector.size();)
				{
					id = strVector[i+1];
					phone = strVector[i+2];
					stat = strVector[i+3];
					m_listSysRunInfo.SetItemStat(atoi(id.c_str()),phone,stat);
					i +=4;
				}
			}
		}
		break;
	default:
		break;
	}
	return CWnd::WindowProc(message, wParam, lParam);

}


BOOL CRuiTongIVRGUIDlg::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	//�������escape������С��ϵͳ������
	UINT nID = LOWORD(wParam);
	int nCode = HIWORD(wParam);
	HWND hWndCtrl = (HWND)lParam;
	
	if(nID==2&&nCode==0&&hWndCtrl==NULL)
	{
//		MinimizeSysToTray();
		return TRUE;
	}
	
	return CDialog::OnCommand(wParam, lParam);
}

void CRuiTongIVRGUIDlg::OnButtonSysRun() 
{
}

void CRuiTongIVRGUIDlg::OnButtonSysPause() 
{
	//if(glo_storeData.GetServerStatus()->GetParentThreadStatus() == CServerStatus::Running)
	//{
	//	glo_storeData.GetServerStatus()->SetPause();
	//	glo_myDisplay.PutLine(CSysInfoDisplay::Message,"ϵͳ��ͣ����");
	//	GetDlgItem(IDC_BUTTON_SYS_PAUSE)->SetWindowText("ϵͳ�ָ�");
	//}
	//else if(glo_storeData.GetServerStatus()->GetParentThreadStatus() == CServerStatus::Pause)
	//{
	//	glo_storeData.GetServerStatus()->SetResume();
	//	glo_myDisplay.PutLine(CSysInfoDisplay::Message,"ϵͳ�ָ�����");
	//	GetDlgItem(IDC_BUTTON_SYS_PAUSE)->SetWindowText("ϵͳ��ͣ");
	//}
	//else
	//	glo_myDisplay.PutLine(CSysInfoDisplay::Message,"״̬����ȷ��������ͣ��ָ�");
}

void CRuiTongIVRGUIDlg::OnButtonSysStop() 
{

	DWORD dwID = IDC_EDIT_LINE_NO;
	CEdit* pEdit = (CEdit*)GetDlgItem(dwID);
	CString szText;
	pEdit->GetWindowText(szText);
	char szNum[128] ="";
	sprintf(szNum,"%s",szText.Trim());
	
	for (int j = 0;j<strlen(szNum);j++)
	{
		if (isdigit(szNum[j]) == 0)
		{
			GLog(log4cplus::ERROR_LOG_LEVEL,"�������·��[%s]��������������",szText);
			return;
		}
	}

	if(szText.Trim().GetLength() ==0 )
	{
		GLog(log4cplus::ERROR_LOG_LEVEL,"�������·��[%s]��������������",szText);
		return;
	}


	bool isRight = false;
	for(UINT i = 0;i <g_psApp.size();i++)
	{
		if(atoi(szText) == atoi(g_psApp[i].first.c_str()))
		{
			isRight = true;
			break;
		}
	}

	if (isRight)
	{
		GLog("����ֹͣ�����Ϣ��app��[%s] ",szText);
		std::string queueName = MSG_QUEUE_TAG;
		queueName += szText.GetString();
		CMessage msg;
		msg.SendExitMsg(queueName);
	}
	else
	{
		GLog(log4cplus::ERROR_LOG_LEVEL,"�������·��[%s]��������������",szText);
	}
}

void CRuiTongIVRGUIDlg::OnButtonSysQuit() 
{

		if(IDYES == AfxMessageBox("�Ƿ�Ҫ�˳���",MB_YESNO))
		{
			::RemoveProp(m_hWnd,g_szTitle);
			QuitSystem();
			CDialog::OnOK();
		}

}

void CRuiTongIVRGUIDlg::OnTimer(UINT nIDEvent) 
{

	CTime tmNow = CTime::GetCurrentTime();
	CString szNow;
	szNow.Format("%02d%02d %02d:%02d:%02d",
		tmNow.GetMonth(),tmNow.GetDay(),
		tmNow.GetHour(),tmNow.GetMinute(),tmNow.GetSecond());
	DWORD dwID = IDC_EDIT_SYS_CUR_TIME;
	CEdit* pEdit = (CEdit*)GetDlgItem(dwID);
	pEdit->SetWindowText(szNow.GetString());


	CDialog::OnTimer(nIDEvent);
}


void CRuiTongIVRGUIDlg::OnBnClickedButtonRestartMonitor()
{


	vector<string> strV;
		//m_memMsg.Read(strV);
	
		string msg;
		std::stringstream ss;
		CTime time = CTime::GetCurrentTime();   
	
		for (int i = 0;i<g_iChannelNum;i++)
		{
			ss  << "app:"
				<< i
				<< ":"
				<< rand()
				<< ":"
				<< rand()
				<< "\n";
			//msg += ss.str();
		}
	msg = ss.str();
	m_memMsg.Write(msg);

	PostMessage(WM_APP_WRITE_DATA,0,0);
	GLog("post msg WM_APP_WRITE_DATA ");
	GLog("msg: [%s]",msg.c_str());
}
